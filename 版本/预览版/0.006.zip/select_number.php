<?php
session_start();
require_once __DIR__.'/includes/functions.php';

// 检查会话中是否存在申请数据，如果没有则返回第一步
if (!isset($_SESSION['application_data'])) {
    header("Location: apply.php");
    exit;
}

$db = db();
$error = '';

// 获取系统配置
$stmt_config = $db->query("SELECT config_key, config_value FROM system_config WHERE config_key IN ('number_auto_generate', 'sponsor_message')");
$config = $stmt_config->fetchAll(PDO::FETCH_KEY_PAIR);
$is_auto_generate_enabled = (bool)($config['number_auto_generate'] ?? false);
$sponsor_message = $config['sponsor_message'] ?? '选择靓号或自定义号码是对我们服务的肯定，如果您愿意，可以对我们进行赞赏以支持我们更好地发展！';

// 处理最终的表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_number = trim($_POST['number'] ?? '');
    
    if (empty($selected_number)) {
        $error = '请选择一个备案号。';
    } else {
        $app_data = $_SESSION['application_data'];
        $db->beginTransaction();
        try {
            $stmt = $db->prepare("
                INSERT INTO icp_applications (number, website_name, domain, description, owner_name, owner_email, status, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, 'pending', CURRENT_TIMESTAMP)
            ");
            $stmt->execute([
                $selected_number, $app_data['site_name'], $app_data['domain'],
                $app_data['description'], $app_data['contact_name'], $app_data['contact_email']
            ]);
            $application_id = $db->lastInsertId();
            
            if (!$is_auto_generate_enabled) {
                $stmt_update = $db->prepare("UPDATE selectable_numbers SET status = 'used', used_by = ?, used_at = CURRENT_TIMESTAMP WHERE number = ?");
                $stmt_update->execute([$application_id, $selected_number]);
            }
            
            $db->commit();
            unset($_SESSION['application_data']);
            header("Location: result.php?application_id=" . $application_id);
            exit;
        } catch (Exception $e) {
            $db->rollBack();
            $error = '处理您的请求时发生错误，请重试。';
        }
    }
}

// 页面首次加载时获取号码的逻辑与API文件(get_numbers.php)一致
// ... (为了代码简洁，此处的号码获取逻辑将在页面加载后由AJAX自动执行) ...

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>选择备案号 - Yuan-ICP</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
    <style>
        .selector-container { max-width: 800px; margin: 0 auto; padding: 2rem; background: #fff; border-radius: 8px; box-shadow: 0 0 15px rgba(0,0,0,0.1); }
        .form-header { text-align: center; margin-bottom: 2rem; }
        .step-indicator { display: flex; justify-content: space-between; margin-bottom: 2rem; }
        .step { text-align: center; flex: 1; position: relative; }
        .step-number { width: 40px; height: 40px; background: #e9ecef; color: #495057; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-weight: bold; border: 2px solid #dee2e6; }
        .step.completed .step-number { background: #28a745; color: white; border-color: #28a745; }
        .step.active .step-number { background: #4a6cf7; color: white; border-color: #4a6cf7; }
        .step:not(:last-child)::after { content: ''; position: absolute; top: 20px; left: 70%; width: 60%; height: 2px; background: #ddd; z-index: -1; }
        
        .number-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 1rem; margin-top: 1.5rem; min-height: 150px; }
        .number-card { border: 2px solid #dee2e6; border-radius: 8px; padding: 1rem; text-align: center; cursor: pointer; transition: all 0.3s; position: relative; overflow: hidden; }
        .number-card:hover { border-color: #6e8efb; transform: translateY(-3px); box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
        .number-card.selected { border-color: #4a6cf7; background-color: #f0f3ff; font-weight: bold; box-shadow: 0 0 0 3px rgba(74, 108, 247, 0.3); }
        .number-card .number { font-size: 1.2rem; font-weight: bold; }
        .premium-badge { position: absolute; top: -1px; right: -1px; background: #ffc107; color: #333; padding: 2px 8px; font-size: 0.75rem; border-radius: 0 8px 0 8px; font-weight: bold; }
        .nav-tabs .nav-link { color: #6c757d; }
        .nav-tabs .nav-link.active { color: #0d6efd; font-weight: bold; }
        .loading-spinner { display: none; }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container"><a class="navbar-brand" href="index.php">Yuan-ICP</a></div>
    </nav>

    <div class="container my-5">
        <div class="selector-container">
            <!-- 步骤指示器 -->
            <div class="step-indicator">
                <div class="step completed"><div class="step-number"><i class="fas fa-check"></i></div><div class="step-title">填写信息</div></div>
                <div class="step active"><div class="step-number">2</div><div class="step-title">选择号码</div></div>
                <div class="step"><div class="step-number">3</div><div class="step-title">完成申请</div></div>
            </div>
            
            <div class="form-header">
                <h2>选择备案号</h2>
                <p class="text-muted">为您的网站选择一个心仪的备案号</p>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <!-- 选项卡 -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="random-tab" data-bs-toggle="tab" data-bs-target="#random" type="button" role="tab">随机选号</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="custom-tab" data-bs-toggle="tab" data-bs-target="#custom" type="button" role="tab">自定义靓号</button>
                </li>
            </ul>

            <form method="post" id="number-form">
                <input type="hidden" name="number" id="selected_number">
                
                <div class="tab-content" id="myTabContent">
                    <!-- 随机选号 Tab -->
                    <div class="tab-pane fade show active" id="random" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <h5 class="mb-0">请选择一个号码</h5>
                            <button type="button" class="btn btn-outline-primary" id="refresh-numbers">
                                <span class="spinner-border spinner-border-sm loading-spinner" role="status" aria-hidden="true"></span>
                                <i class="fas fa-sync-alt me-1"></i>换一批
                            </button>
                        </div>
                        <div class="number-grid" id="number-grid-container">
                            <!-- 号码卡片将由JS动态加载 -->
                        </div>
                    </div>

                    <!-- 自定义靓号 Tab -->
                    <div class="tab-pane fade" id="custom" role="tabpanel">
                        <div class="mt-3 p-3 border rounded">
                            <h5 class="mb-3">输入您想要的号码</h5>
                            <div class="input-group">
                                <input type="text" class="form-control" id="custom_number_input" placeholder="例如：Yuan-ICP-888888">
                                <button class="btn btn-primary" type="button" id="select-custom-number">就选这个!</button>
                            </div>
                            <div class="form-text mt-2">自定义号码需要赞赏支持。选定后，您的号码将被标记为 <strong id="custom-selection-display" class="text-success d-none"></strong></div>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid gap-2 mt-4">
                    <button type="submit" id="submit-btn" class="btn btn-primary btn-lg" disabled>确认选择并完成申请</button>
                    <a href="apply.php" class="btn btn-outline-secondary">返回修改信息</a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- 赞赏提示 Modal -->
    <div class="modal fade" id="sponsorModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-gem text-warning me-2"></i>靓号选择确认</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>您选择了一个靓号/自定义号码，非常感谢您的青睐！</p>
                    <div class="alert alert-info">
                        <?php echo nl2br(htmlspecialchars($sponsor_message)); ?>
                    </div>
                    <p>此操作遵循君子协议，点击下方按钮即表示您已知晓并愿意支持我们。</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">再想想</button>
                    <button type="button" class="btn btn-primary" id="confirm-sponsor-btn">我确认并继续</button>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center"><p class="mb-0">&copy; <?php echo date('Y'); ?> Yuan-ICP. 保留所有权利。</p></div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const hiddenInput = document.getElementById('selected_number');
        const submitBtn = document.getElementById('submit-btn');
        const numberGridContainer = document.getElementById('number-grid-container');
        const refreshBtn = document.getElementById('refresh-numbers');
        const customInput = document.getElementById('custom_number_input');
        const selectCustomBtn = document.getElementById('select-custom-number');
        const customSelectionDisplay = document.getElementById('custom-selection-display');
        
        const sponsorModalEl = document.getElementById('sponsorModal');
        const sponsorModal = new bootstrap.Modal(sponsorModalEl);
        const confirmSponsorBtn = document.getElementById('confirm-sponsor-btn');

        let selectedNumberIsPremium = false;

        // 函数：获取并渲染号码
        async function fetchAndRenderNumbers() {
            refreshBtn.disabled = true;
            refreshBtn.querySelector('.loading-spinner').style.display = 'inline-block';
            refreshBtn.querySelector('.fa-sync-alt').style.display = 'none';
            numberGridContainer.innerHTML = '<div class="col-12 text-center p-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
            
            try {
                const response = await fetch('api/get_numbers.php');
                const data = await response.json();
                
                numberGridContainer.innerHTML = ''; // 清空
                if (data.success && data.numbers.length > 0) {
                    data.numbers.forEach(num => {
                        const card = document.createElement('div');
                        card.className = 'number-card';
                        card.dataset.number = num.number;
                        card.dataset.premium = num.is_premium ? '1' : '0';
                        
                        let premiumBadge = num.is_premium ? '<div class="premium-badge"><i class="fas fa-gem"></i> 靓号</div>' : '';
                        card.innerHTML = `${premiumBadge}<div class="number">${num.number}</div>`;
                        
                        card.addEventListener('click', handleNumberSelection);
                        numberGridContainer.appendChild(card);
                    });
                } else {
                    numberGridContainer.innerHTML = '<div class="col-12 text-center p-3 alert alert-warning">暂无可用号码，请稍后重试。</div>';
                }
            } catch (error) {
                console.error('Error fetching numbers:', error);
                numberGridContainer.innerHTML = '<div class="col-12 text-center p-3 alert alert-danger">加载号码失败，请检查网络或联系管理员。</div>';
            } finally {
                refreshBtn.disabled = false;
                refreshBtn.querySelector('.loading-spinner').style.display = 'none';
                refreshBtn.querySelector('.fa-sync-alt').style.display = 'inline-block';
            }
        }
        
        // 函数：处理号码选择逻辑
        function handleNumberSelection(event) {
            const card = event.currentTarget;
            const number = card.dataset.number;
            const isPremium = card.dataset.premium === '1';

            // 清理所有选中状态
            clearAllSelections();
            
            // 标记卡片为选中
            card.classList.add('selected');
            
            // 设置隐藏域的值
            hiddenInput.value = number;
            selectedNumberIsPremium = isPremium;

            // 如果是靓号，弹出赞赏提示
            if (isPremium) {
                sponsorModal.show();
            } else {
                submitBtn.disabled = false;
            }
        }

        // 函数：处理自定义号码选择
        function handleCustomNumberSelection() {
            const number = customInput.value.trim();
            if (number === '') {
                alert('请输入您想要的号码！');
                return;
            }
            
            clearAllSelections();
            
            hiddenInput.value = number;
            selectedNumberIsPremium = true; // 自定义号码视为靓号
            
            customSelectionDisplay.textContent = `已选定: ${number}`;
            customSelectionDisplay.classList.remove('d-none');

            sponsorModal.show();
        }

        // 函数：清除所有选中状态
        function clearAllSelections() {
            document.querySelectorAll('.number-card.selected').forEach(c => c.classList.remove('selected'));
            submitBtn.disabled = true;
            hiddenInput.value = '';
            customSelectionDisplay.classList.add('d-none');
            selectedNumberIsPremium = false;
        }

        // 事件绑定
        refreshBtn.addEventListener('click', fetchAndRenderNumbers);
        selectCustomBtn.addEventListener('click', handleCustomNumberSelection);
        
        // Modal关闭时，如果用户没点确认，则取消选择
        sponsorModalEl.addEventListener('hide.bs.modal', function () {
            if (!submitBtn.disabled) {
                // 如果按钮已启用（意味着用户点了确认），则什么都不做
            } else {
                clearAllSelections(); // 否则，用户点了关闭或取消，清除选择
            }
        });

        // Modal内的确认按钮
        confirmSponsorBtn.addEventListener('click', function() {
            submitBtn.disabled = false; // 启用最终提交按钮
            sponsorModal.hide();
        });

        // 页面加载时自动获取第一批号码
        fetchAndRenderNumbers();
    });
    </script>
</body>
</html>
