<?php
// 从传递的 $data 数组中解压变量
extract($data); 
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title ?? ($config['site_name'] ?? 'Yuan-ICP')); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($config['seo_description'] ?? ''); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($config['seo_keywords'] ?? ''); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            padding: 4rem 0;
            margin-bottom: 2rem;
        }
        .query-container, .apply-form, .result-container {
            max-width: 800px;
            margin: 5rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php"><?php echo htmlspecialchars($config['site_name'] ?? 'Yuan-ICP'); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($active_page ?? '') === 'home' ? 'active' : ''; ?>" href="index.php">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($active_page ?? '') === 'apply' ? 'active' : ''; ?>" href="apply.php">申请备案</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($active_page ?? '') === 'query' ? 'active' : ''; ?>" href="query.php">备案查询</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="leap.php">网站迁跃</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
